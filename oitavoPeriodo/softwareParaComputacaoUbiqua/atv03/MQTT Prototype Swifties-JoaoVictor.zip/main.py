# =============================================================
# Prototipo 3 - Comunicacao e Resiliencia (M1 a M5)
# Sistemas Ubiquos - manutencao preditiva
# MicroPython / ESP32 / Wokwi
#
# Versao minima: I/O, Wi-Fi, NTP, contrato de evento, eco como
# confirmacao, buffer local, retransmissao e deduplicacao.
# =============================================================

from machine import Pin, ADC
from umqtt.simple import MQTTClient
import network, ntptime, ujson, time

# ---------- Identidade (contrato de evento) ----------
NODE_ID = "esp32-07"
ASSET_ID = "motor-linha3-02"

# TROQUE o prefixo: broker publico e compartilhado
PREFIXO = "ubiq/swifties/motor-linha3-02"
TOPICO_EVENTOS = PREFIXO + "/eventos"

BROKER = "broker.hivemq.com"
PORTA = 1883

# ---------- Parametros ----------
INTERVALO_EVENTO = 2000   # gera evento a cada 2 s
TIMEOUT_ACK = 4000        # sem eco em 4 s -> reenvia
BUFFER_MAX = 20
EPOCH_OFFSET = 946684800  # MicroPython conta de 2000, Unix de 1970

# ---------- M1: I/O ----------
led_r, led_g, led_b = Pin(25, Pin.OUT), Pin(26, Pin.OUT), Pin(27, Pin.OUT)
pot = ADC(Pin(34))
pot.atten(ADC.ATTN_11DB)
btn = Pin(4, Pin.IN, Pin.PULL_UP)


def cor(r, g, b):
    led_r.value(r)
    led_g.value(g)
    led_b.value(b)


# ---------- Estado ----------
buffer = []        # eventos ainda nao confirmados
seq_atual = 0
vistos = set()     # seq ja confirmados (deduplicacao)
ok = dup = reenvios = descartados = 0
cliente = None


# ---------- M2: rede e relogio ----------
def conectar_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        wlan.connect("Wokwi-GUEST", "")
        while not wlan.isconnected():
            time.sleep_ms(200)
    print("[WIFI] ok", wlan.ifconfig()[0])


def agora_iso():
    t = time.gmtime(time.time())
    return "%04d-%02d-%02dT%02d:%02d:%02dZ" % (t[0], t[1], t[2], t[3], t[4], t[5])


# ---------- M4: eco recebido = confirmacao ----------
def ao_receber(topico, payload):
    global ok, dup
    try:
        e = ujson.loads(payload)
    except Exception:
        return
    if e.get("node_id") != NODE_ID:
        return

    seq = e.get("seq")
    if seq in vistos:                      # M5: deduplicacao por (node_id, seq)
        dup += 1
        print("[DUPLICADO] seq=%d descartado por idempotencia" % seq)
        return

    vistos.add(seq)
    ok += 1
    for i, ev in enumerate(buffer):        # confirma e libera o slot
        if ev["seq"] == seq:
            buffer.pop(i)
            break
    print("[CONFIRMADO] seq=%d  (ok=%d dup=%d reenv=%d perdidos=%d)"
          % (seq, ok, dup, reenvios, descartados))


def conectar_mqtt():
    global cliente
    cliente = MQTTClient(NODE_ID + str(time.ticks_ms() % 9999), BROKER, PORTA)
    cliente.set_callback(ao_receber)
    cliente.connect()
    cliente.subscribe(TOPICO_EVENTOS)      # assina o proprio topico
    print("[MQTT] conectado")


# ---------- M3: contrato de evento ----------
def gerar_evento():
    global seq_atual, descartados
    if len(buffer) >= BUFFER_MAX:          # M5: perda explicita
        descartados += 1
        print("[PERDA] buffer cheio, evento descartado")
        return

    seq_atual += 1
    valor = pot.read() * 4.0 / 4095.0      # rms normalizado, 0.00 a 4.00
    buffer.append({
        "seq": seq_atual,
        "ts": agora_iso(),
        "valor": round(valor, 2),
        "enviado_em": None,
        "tentativas": 0,
    })
    print("[GERADO] seq=%d valor=%.2f" % (seq_atual, valor))


def publicar(ev):
    msg = ujson.dumps({
        "tipo": "medicao.vibracao",
        "node_id": NODE_ID,
        "asset_id": ASSET_ID,
        "seq": ev["seq"],
        "ts_evento": ev["ts"],
        "valor": ev["valor"],
        "tentativa": ev["tentativas"] + 1,
    })
    cliente.publish(TOPICO_EVENTOS, msg)
    ev["enviado_em"] = time.ticks_ms()
    ev["tentativas"] += 1


# ---------- M5: store-and-forward ----------
def tratar_pendencias():
    global reenvios
    for ev in buffer:
        nunca = ev["enviado_em"] is None
        expirou = (not nunca and
                   time.ticks_diff(time.ticks_ms(), ev["enviado_em"]) > TIMEOUT_ACK)
        if nunca or expirou:
            if expirou:
                reenvios += 1
                print("[SEM ECO] seq=%d -> reenvio" % ev["seq"])
            publicar(ev)
            return                          # um por ciclo


def atualizar_led(online):
    if not online:
        cor(1, 0, 0)                        # vermelho: sem enlace
    elif len(buffer) >= BUFFER_MAX:
        cor(0, 0, 1)                        # azul: buffer cheio, ha perda
    elif buffer:
        cor(1, 1, 0)                        # amarelo: drenando pendencias
    else:
        cor(0, 1, 0)                        # verde: em dia


# ---------- Principal ----------
cor(0, 0, 1)
conectar_wifi()
ntptime.settime()
print("[NTP]", agora_iso())
conectar_mqtt()

t_evento = time.ticks_ms()

while True:
    online = True
    try:
        cliente.check_msg()                 # nao bloqueante
        tratar_pendencias()
    except OSError:
        online = False
        print("[MQTT] caiu, reconectando...")
        try:
            conectar_mqtt()
        except OSError:
            time.sleep_ms(2000)

    if time.ticks_diff(time.ticks_ms(), t_evento) > INTERVALO_EVENTO:
        t_evento = time.ticks_ms()
        gerar_evento()                      # continua sensoriando mesmo offline

    atualizar_led(online)
    time.sleep_ms(50)