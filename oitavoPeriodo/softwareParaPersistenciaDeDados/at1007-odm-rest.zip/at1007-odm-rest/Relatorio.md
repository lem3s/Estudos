# Transações — ODM com API REST

Aluno: João Victor Lemes Faria — 202302614

Implementação ODM de uma entidade `Transacao` com Spring Data MongoDB, exposta por uma API REST com CRUD completo. 

## Como rodar

1. Subir o MongoDB:

   ```bash
   docker run -d --name mongodb -p 27017:27017 -v mongodb_data:/data/db mongodb/mongodb-community-server:latest
   ```

2. Iniciar a API (a partir de `webapi/`):

   ```bash
   ./mvnw spring-boot:run
   ```

A API sobe em `http://localhost:8080` e grava no banco `meu_banco`, coleção `transacao`.

## OpenAPI

A documentação é gerada automaticamente pelo springdoc-openapi a partir do controller:

- Swagger UI: `http://localhost:8080/swagger-ui.html`

## Entidade `Transacao`

- `id` (`String`): `@Id`, ObjectId gerado pelo MongoDB
- `descricao` (`String`): descrição do lançamento
- `valorEmCentavos` (`int`): valor em centavos (evita erro de ponto flutuante)
- `tipo` (`TipoTransacao`): `RECEITA` ou `DESPESA`
- `categoria` (`String`): ex.: `alimentacao`, `salario`
- `data` (`LocalDate`): data no formato `AAAA-MM-DD`

## Endpoints

- `POST /transacoes`
- `GET /transacoes`
- `GET /transacoes/{id}`
- `PUT /transacoes/{id}`
- `DELETE /transacoes/{id}`

## Exemplos

```bash
# Criar
curl -X POST localhost:8080/transacoes -H 'Content-Type: application/json' \
  -d '{"descricao":"Mercado","valorEmCentavos":15990,"tipo":"DESPESA","categoria":"alimentacao","data":"2026-10-07"}'

# Listar
curl localhost:8080/transacoes

# Buscar por id
curl localhost:8080/transacoes/{id}

# Atualizar
curl -X PUT localhost:8080/transacoes/{id} -H 'Content-Type: application/json' \
  -d '{"descricao":"Salario","valorEmCentavos":500000,"tipo":"RECEITA","categoria":"salario","data":"2026-10-05"}'

# Remover
curl -X DELETE localhost:8080/transacoes/{id}
```

## Resultados

### Criação de transação (`POST /transacoes`) pelo Swagger UI

Resposta `201` com o documento persistido e o `id` gerado pelo MongoDB, que roda no container `mongodb` (à direita).

![Criação de transação](PrintCriacaoTransacao.png)

### Listagem de transações (`GET /transacoes`) pelo Swagger UI

Resposta `200` com a transação criada anteriormente, lida do banco.

![Listagem de transações](PrintAtualizacao.png)

## Conclusão

Com o Spring Data MongoDB, a persistência se torna muito mais simples. O ODM converte o objeto Java em documento BSON e o controller expõe as operações CRUD sobre HTTP, retornando 404 quando o id não existe.
